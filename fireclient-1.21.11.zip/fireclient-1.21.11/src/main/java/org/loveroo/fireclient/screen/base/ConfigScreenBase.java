package org.loveroo.fireclient.screen.base;

import org.loveroo.fireclient.RooHelper;
import org.loveroo.fireclient.client.FireClientside;
import org.loveroo.fireclient.data.FireClientOption;
import org.lwjgl.glfw.GLFW;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

public class ConfigScreenBase extends Screen {

    protected int mouseState = 0;

    protected int mouseX = 0;
    protected int mouseY = 0;

    protected int oldMouseY = 0;
    protected int oldMouseX = 0;

    protected ConfigScreenBase(Text title) {
        super(title);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        mouseState = click.button();

        this.oldMouseX = this.mouseX;
        this.oldMouseY = this.mouseY;

        handleClick();

        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseReleased(Click click) {
        mouseState = -1;
        handleClick();

        FireClientside.saveConfig();

        return super.mouseReleased(click);
    }

    protected void handleClick() { }

    @Override
    public void removed() {
        onExit();
    }

    protected void onExit() { }

    @Override
    public boolean keyPressed(KeyInput input) {
        if(client.options.inventoryKey.matchesKey(input)) {
            exitOnInventory();
        }

        if(input.key() == GLFW.GLFW_KEY_ESCAPE) {
            if(escapePressed()) {
                return true;
            }
        }

        return super.keyPressed(input);
    }

    protected void exitOnInventory() {
        if(client.player == null || getFocused() instanceof TextFieldWidget) {
            return;
        }

        if(getFocused() instanceof ScrollableWidget scroll) {
            if(scroll.getFocused().getFocused() instanceof TextFieldWidget) {
                return;
            }
        }

        client.setScreen(new InventoryScreen(client.player));
    }

    protected boolean escapePressed() {
        return false;
    }

    protected boolean doSnap() {
        return (GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS);
    }

    protected boolean showTransform() {
        return (GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        this.mouseX = mouseX;
        this.mouseY = mouseY;

        var text = MinecraftClient.getInstance().textRenderer;

        var configText = RooHelper.gradientText(Text.translatable("fireclient.screen.generic.header").getString(), FireClientside.mainColor1, FireClientside.mainColor2);
        context.drawCenteredTextWithShadow(text, configText, width/2, 10, 0xFFFFFFFF);
    }

    protected void renderTutorialText(DrawContext context, Text text) {
        if(FireClientside.getSetting(FireClientOption.SHOW_TUTORIAL_TEXT) == 0) {
            return;
        }

        var gradientText = RooHelper.gradientText(text.getString(), FireClientside.mainColor1, FireClientside.mainColor2);
        context.drawText(textRenderer, gradientText, 2, height-10, 0xFFFFFFFF, true);
    }

    public int getMouseX() {
        return mouseX;
    }

    public int getMouseY() {
        return mouseY;
    }
}
